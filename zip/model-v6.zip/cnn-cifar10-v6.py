import os
import sys
from os import path

# 入力データ用ディレクトリ
DATA_DIR = os.environ["DATA_DIR"]
# 出力データ用ディレクトリ
RESULT_DIR = os.environ["RESULT_DIR"]

# Main script

def main(model_result_name):
    # Model needs to be stored in $RESULTS_DIR/model (#3660)
    # モデルファイルのパス名を生成
    model_result_path = path.join(RESULT_DIR, "model", model_result_name) 

    print("Starting DL model training...")
    print("DATA_DIR: %s" % DATA_DIR)
    print("RESULT_DIR: %s" % RESULT_DIR)
    print("MODEL_RESULT_PATH: %s" % model_result_path)

if __name__ == "__main__":
    main(sys.argv[1])


######### pickle データの読み込み ################
# 読み込みデータはDATA_DIR配下にある前提 

import pickle
from keras.utils import np_utils

with open(path.join(DATA_DIR, 'cifar-10-tf-train.pkl'), 'rb') as f:
    train_data, train_label = pickle.load(f)
    train_data = train_data.astype('float32') / 255   
    # class_labels_count: 分類クラス数(10)
    class_labels_count = len(set(train_label.flatten()))
    train_label = np_utils.to_categorical(train_label, class_labels_count)

with open(path.join(DATA_DIR, 'cifar-10-tf-valid.pkl'), 'rb') as f:
    val_data, val_label = pickle.load(f)
    val_data = val_data.astype('float32') / 255   
    val_label = np_utils.to_categorical(val_label, class_labels_count)

with open(path.join(DATA_DIR, 'cifar-10-tf-test.pkl'), 'rb') as f:
    test_data, test_label = pickle.load(f)
    test_data = test_data.astype('float32') / 255   
    test_label = np_utils.to_categorical(test_label, class_labels_count)
#################################################


# 学習繰り返し回数
nb_epoch = 50

# 1回の学習で何枚の画像を使うか
batch_size = 128

# 学習係数 デフォルト値
learning_rate = 0.0001

# ドロップアウト率 デフォルト値
dropout_rate1 = 0.25
dropout_rate2 = 0.50

############ HPO パラメータ読み取り##############
import json

try:
    with open("config.json", 'r') as f:
        json_obj = json.load(f)
    learning_rate = json_obj['learning_rate']
    dropout_rate1 = json.obj['dropout_rate1']
    dropout_rate2 = json.obj['dropout_rate2']
except:
    pass

print('learning_rate: %s' % learning_rate)
print('dropout_rate1: %s' % dropout_rate1)
print('dropout_rate2: %s' % dropout_rate2)

# SUBIDの取得関数
def getCurrentSubID():
    if "SUBID" in os.environ:
        return os.environ["SUBID"]
    else:
        return None
##############################################

############ HPOMetrics関数の定義 ##############
from emetrics import EMetrics
import keras

class HPOMetrics(keras.callbacks.Callback):
    def __init__(self):
        self.emetrics = EMetrics.open(getCurrentSubID())
        subid = getCurrentSubID()
        print("")  # dummry cr
        print("subid = %s  lr = %f drop1 = %f drop2 = %f" % (subid, learning_rate, dropout_rate1, dropout_rate2))

    def on_epoch_end(self, epoch, logs={}):
        train_results = {}
        test_results = {}
        print("") # dummy cr
        for key, value in logs.items():
            subid = getCurrentSubID()
            print("subid = %s  key = %s  item = %s" % (subid, key, value))
            if 'val_acc' == key:
                test_results.update({'val_acc': value})
            if 'val_loss' == key:
                test_results.update({'val_loss': value})
 
        print('EPOCH ' + str(epoch))
        self.emetrics.record(EMetrics.TEST_GROUP, epoch, test_results)

    def close(self):
        self.emetrics.close()
#################################################

########## TessorBloard初期化 #################
from os import environ
from keras.callbacks import TensorBoard

#writing metrics
if environ.get('JOB_STATE_DIR') is not None:
    tb_directory = os.path.join(os.environ["JOB_STATE_DIR"], "logs", "tb", "test")
else:
    tb_directory = os.path.join("logs", "tb", "test")

print('tb_directory: %s' % tb_directory)
os.makedirs(tb_directory, exist_ok=True)
tensorboard = TensorBoard(log_dir=tb_directory)
##############################################


######### CNNモデル作成 ########################
# ここは普通のKerasコーディングでいい
# 正しいHPOパラメータの外だしだけ意識する (この例ではlearning_rate)

# 必要ライブラリのロード
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, Activation
from keras import optimizers

def cnn_model(X_train, class_labels_count):
    model = Sequential()
    model.add(Conv2D(32, (3, 3), padding="same", input_shape=X_train.shape[1:]))
    model.add(Activation('relu'))
    model.add(Conv2D(32, (3, 3))) 
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(dropout_rate1))
    model.add(Conv2D(64, (3, 3), padding='same'))
    model.add(Activation('relu'))
    model.add(Conv2D(64, (3, 3)))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(dropout_rate1))
    model.add(Flatten())
    model.add(Dense(512))
    model.add(Activation('relu'))
    model.add(Dropout(dropout_rate2))
    model.add(Dense(class_labels_count))
    model.add(Activation('softmax'))
    # learning_rateはパラメータ値を使う
    adam = optimizers.Adam(lr = learning_rate)
    model.compile(
        loss='categorical_crossentropy',
        optimizer=adam,
        metrics=['accuracy']
    )
    return model

# モデル生成
model = cnn_model(train_data, class_labels_count)
######################################################

################## 学習・評価 ##########################
# HPOMetrics関数初期化
hpo = HPOMetrics()

# コールバック関数にTensorboardとhpoを指定する

history = model.fit(
    train_data, train_label, batch_size=batch_size, epochs=nb_epoch, verbose=1,
    validation_data=(val_data, val_label), shuffle=True, callbacks=[tensorboard,hpo]
)

hpo.close()

# テストデータで認識率計算
test_scores = model.evaluate(test_data, test_label, verbose=1)
print(test_scores)
#######################################################


################# モデルの保存 ##########################
# 呼出し元プログラムによりmodel_result_pathが設定されている
# 設定されていない場合は"./keras_model.hdf5"に保存

print('Saving the model...')
if 'model_result_path' not in locals() and 'model_result_path' not in globals():
    model_result_path = "./keras_model.hdf5"
model.save(model_result_path)
print("Model saved in file: %s" % model_result_path)
#######################################################
