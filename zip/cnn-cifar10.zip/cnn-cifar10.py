# CNN on CIFAR-10 
# Watson Studio Sample Program
# step 3
# HPO連携

# 学習繰り返し回数
#nb_epoch = 50
nb_epoch = 2

# 分類クラス数
num_classes = 10

# 1回の学習で何枚の画像を使うか
batch_size = 64

# 学習係数 デフォルト値
learning_rate = 0.001

import os
import sys
from os import path

# 入力データ用ディレクトリ
DATA_DIR = os.environ["DATA_DIR"]

# 出力データ用ディレクトリ
RESULT_DIR = os.environ["RESULT_DIR"]

# 出力ファイルパス (mainで設定される。変数名だけ定義)
model_result_path = None

# Main script

def main(model_result_name):
    # モデルファイルの保存先ディレクトリの作成
    model_result_dir  = path.join(RESULT_DIR, "model")
    os.makedirs(model_result_dir, exist_ok=True)
    
    # モデルファイルのパス名(グローバル変数に設定)
    global model_result_path
    model_result_path = path.join(model_result_dir, model_result_name) 

    print("Starting DL model training...")
    print("DATA_DIR: %s" % DATA_DIR)
    print("RESULT_DIR: %s" % RESULT_DIR)
    print("MODEL_RESULT_PATH: %s" % model_result_path)

if __name__ == "__main__":
    main(sys.argv[1])

print('model_result_path: %s' % model_result_path)

######### pickle データの読み込み ################
# 読み込みデータはDATA_DIR配下にある前提 

import pickle
from keras.utils import np_utils

with open(path.join(DATA_DIR, 'cifar-10-tf-train.pkl'), 'rb') as f:
    train_data, train_label = pickle.load(f)
    train_data = train_data.astype('float32')  
    train_label = np_utils.to_categorical(train_label, num_classes)

with open(path.join(DATA_DIR, 'cifar-10-tf-valid.pkl'), 'rb') as f:
    val_data, val_label = pickle.load(f)
    val_data = val_data.astype('float32')  
    val_label = np_utils.to_categorical(val_label, num_classes)

with open(path.join(DATA_DIR, 'cifar-10-tf-test.pkl'), 'rb') as f:
    test_data, test_label = pickle.load(f)
    test_data = test_data.astype('float32')  
    test_label = np_utils.to_categorical(test_label, num_classes)
#################################################

############ HPO パラメータ読み取り##############
import json
import os

try:
    with open("config.json", 'r') as f:
        json_obj = json.load(f)
    learning_rate = json_obj['learning_rate']
    nb_epoch = json_obj['nb_epoch']
except:
    pass

print('nb_epoch: %d' % nb_epoch)
print('learning_rate: %s' % learning_rate)

# SUBIDの取得関数
def getCurrentSubID():
    if "SUBID" in os.environ:
        return os.environ["SUBID"]
    else:
        return None
##############################################

########## TessorBloard初期化 #################
import os
from keras.callbacks import TensorBoard

# Tensorboardデータ保存用パスの指定
tb_directory = os.environ["LOG_DIR"]+"/"+os.environ["SUBID"]+"/logs/tb"

# Tensorbaordオブジェクトの作成
tensorboard = TensorBoard(log_dir=tb_directory)
##############################################

######### CNNモデル作成 ########################
# ここは普通のKerasコーディングでいい
# 正しいHPOパラメータの外だしだけ意識する (この例ではlearning_rate)

# 必要ライブラリのロード
from keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, Activation, BatchNormalization
from keras import Sequential, regularizers, optimizers

baseMapNum = 32
weight_decay = 1e-4

def cnn_model(x_train, num_classes):
    model = Sequential()
    model.add(Conv2D(baseMapNum, (3,3), padding='same', kernel_regularizer=regularizers.l2(weight_decay), input_shape=x_train.shape[1:]))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(baseMapNum, (3,3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Dropout(0.2))

    model.add(Conv2D(2*baseMapNum, (3,3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(2*baseMapNum, (3,3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Dropout(0.3))

    model.add(Conv2D(4*baseMapNum, (3,3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(4*baseMapNum, (3,3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Dropout(0.4))

    model.add(Flatten())
    model.add(Dense(num_classes, activation='softmax'))

    opt_rms = optimizers.Adam(lr = learning_rate)
    model.compile(loss='categorical_crossentropy', optimizer=opt_rms, metrics=['accuracy'])

    return model

# モデル生成
model = cnn_model(train_data, num_classes)
######################################################

################## 学習・評価 ##########################
# コールバック関数にtensorboardを連携

history = model.fit(
    train_data, train_label, batch_size=batch_size, epochs=nb_epoch, verbose=1,
    validation_data=(val_data, val_label), shuffle=True, callbacks=[tensorboard]
)

# 検証データで最終的なモデル精度計算
test_scores = model.evaluate(test_data, test_label, verbose=1)
print('test_scores: ', test_scores)
print('learning_rate: %s' % learning_rate)
print('nb_epoch: %d' % nb_epoch)

#######################################################
# 検証データによる精度をaccuracyとする
accuracies = [test_scores[1]]

# now write the values out to a JSON formatted file for the 
training_out =[]
for i in range(len(accuracies)):
    training_out.append({'steps':(i+1) , 'accuracy':accuracies[i]})

result_file = '{}/val_dict_list.json'.format(os.environ['RESULT_DIR'])
with open(result_file, 'w') as f:
    json.dump(training_out, f)

################# モデルの保存 ##########################
# 初期設定でmodel_result_pathが設定されている

print('Saving the model...')
model.save(model_result_path)
print("Model saved in file: %s" % model_result_path)
#######################################################
